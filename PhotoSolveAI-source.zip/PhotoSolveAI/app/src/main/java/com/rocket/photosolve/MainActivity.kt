package com.rocket.photosolve

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101F32)
private val Blue = Color(0xFF3478F6)
private val Ink = Color(0xFFEAF2FF)
private val Muted = Color(0xFF9FB2CC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhotoSolveApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoSolveApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("photosolve", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4.1-mini") ?: "gpt-4.1-mini") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatMessage("Привет! Пришли фото задачи или напиши вопрос — разберём решение по шагам.", false)) }
    val scope = rememberCoroutineScope()

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                selectedBitmap = ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.isMutableRequired = false
                    decoder.setTargetSize(1400, 1400)
                }
                error = ""
            } catch (e: Exception) { error = "Не удалось открыть изображение: ${e.localizedMessage}" }
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) { selectedBitmap = bitmap; error = "" }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel,
        onBackground = Ink, onSurface = Ink
    )) {
        if (showSettings) {
            SettingsScreen(
                keyValue = apiKey, onKey = { apiKey = it },
                modelValue = model, onModel = { model = it },
                onSave = {
                    prefs.edit().putString("api_key", apiKey.trim()).putString("model", model.trim()).apply()
                    showSettings = false
                },
                onBack = { showSettings = false }
            )
        } else {
            Scaffold(
                containerColor = Navy,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("PhotoSolve AI", fontWeight = FontWeight.Bold)
                                Text("Решение задач по фото", color = Muted, fontSize = 12.sp)
                            }
                        },
                        actions = {
                            IconButton(onClick = { showSettings = true }) {
                                Icon(Icons.Default.Settings, contentDescription = "Настройки")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Ink)
                    )
                },
                bottomBar = {
                    Column(Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { gallery.launch("image/*") }) {
                                Icon(Icons.Default.AddPhotoAlternate, "Выбрать фото", tint = Blue)
                            }
                            IconButton(onClick = { camera.launch(null) }) {
                                Icon(Icons.Default.CameraAlt, "Сфотографировать", tint = Blue)
                            }
                            BasicTextField(
                                value = input, onValueChange = { input = it },
                                modifier = Modifier.weight(1f).background(Navy, RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp),
                                cursorBrush = androidx.compose.ui.graphics.SolidColor(Blue),
                                decorationBox = { inner ->
                                    Box {
                                        if (input.isEmpty()) Text("Напиши вопрос…", color = Muted, fontSize = 14.sp)
                                        inner()
                                    }
                                }
                            )
                            IconButton(
                                enabled = !busy && (input.isNotBlank() || selectedBitmap != null),
                                onClick = {
                                    val question = input.trim().ifBlank { "Реши задачу на фото. Распознай условие и объясни решение по шагам." }
                                    val bitmap = selectedBitmap
                                    messages.add(ChatMessage(buildString {
                                        append(question)
                                        if (bitmap != null) append("\n📷 Прикреплено фото")
                                    }, true))
                                    input = ""; selectedBitmap = null; busy = true; error = ""
                                    scope.launch {
                                        try {
                                            val answer = withContext(Dispatchers.IO) { askAI(apiKey, model, question, bitmap) }
                                            messages.add(ChatMessage(answer, false))
                                        } catch (e: Exception) {
                                            error = e.message ?: "Не удалось получить ответ"
                                        } finally { busy = false }
                                    }
                                }
                            ) { Icon(Icons.Default.Send, "Отправить", tint = if (busy) Muted else Blue) }
                        }
                        if (selectedBitmap != null) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp, top = 4.dp)) {
                                Text("Фото прикреплено", color = Muted, fontSize = 12.sp)
                                IconButton(onClick = { selectedBitmap = null }) { Icon(Icons.Default.DeleteOutline, "Убрать фото", tint = Muted) }
                            }
                        }
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
                    if (apiKey.isBlank()) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF172B47)), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Подключи ИИ", fontWeight = FontWeight.Bold)
                                Text("Добавь свой API-ключ в настройках, чтобы получать ответы.", color = Muted, fontSize = 13.sp)
                                TextButton(onClick = { showSettings = true }) { Text("Открыть настройки") }
                            }
                        }
                    }
                    if (error.isNotBlank()) {
                        Text(error, color = Color(0xFFFF8585), modifier = Modifier.padding(vertical = 8.dp), fontSize = 13.sp)
                    }
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(messages) { message ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                                Surface(
                                    color = if (message.fromUser) Color(0xFF173D77) else Panel,
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.widthIn(max = 330.dp)
                                ) {
                                    Text(message.text, modifier = Modifier.padding(13.dp), color = Ink, fontSize = 15.sp, lineHeight = 21.sp)
                                }
                            }
                        }
                        if (busy) item { Text("ИИ думает…", color = Muted, modifier = Modifier.padding(8.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    keyValue: String, onKey: (String) -> Unit,
    modelValue: String, onModel: (String) -> Unit,
    onSave: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Navy).statusBarsPadding().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Назад") }
        Text("Настройки ИИ", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text("API-ключ", color = Muted)
        OutlinedTextField(
            value = keyValue, onValueChange = onKey, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Вставь API-ключ") },
            singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Ink, unfocusedTextColor = Ink,
                focusedBorderColor = Blue, unfocusedBorderColor = Muted,
                focusedLabelColor = Blue, cursorColor = Blue
            )
        )
        Spacer(Modifier.height(14.dp))
        Text("Модель", color = Muted)
        OutlinedTextField(
            value = modelValue, onValueChange = onModel, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text("gpt-4.1-mini") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Ink, unfocusedTextColor = Ink,
                focusedBorderColor = Blue, unfocusedBorderColor = Muted, cursorColor = Blue
            )
        )
        Spacer(Modifier.height(8.dp))
        Text("Нужен API-ключ OpenAI с доступом к API и оплачиваемым балансом. Ключ хранится локально на устройстве; не делись им.", color = Muted, fontSize = 13.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") }
    }
}

private fun bitmapToDataUrl(bitmap: Bitmap): String {
    val scaled = if (bitmap.width > 1600 || bitmap.height > 1600) {
        val ratio = minOf(1600f / bitmap.width, 1600f / bitmap.height)
        Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true)
    } else bitmap
    val stream = ByteArrayOutputStream()
    scaled.compress(Bitmap.CompressFormat.JPEG, 82, stream)
    return "data:image/jpeg;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
}

private fun askAI(apiKey: String, model: String, question: String, bitmap: Bitmap?): String {
    if (apiKey.isBlank()) throw IllegalStateException("Сначала добавь API-ключ в настройках.")
    val content = JSONArray()
        .put(JSONObject().put("type", "text").put("text", question))
    if (bitmap != null) {
        content.put(JSONObject().put("type", "image_url")
            .put("image_url", JSONObject().put("url", bitmapToDataUrl(bitmap))))
    }
    val messages = JSONArray()
        .put(JSONObject().put("role", "system").put("content",
            "Ты дружелюбный помощник по учебным задачам. Отвечай на языке пользователя. Если есть фото, внимательно распознай условие. Дай ответ по шагам, покажи вычисления и в конце выдели итог. Если фото нечёткое или данных не хватает, уточни."))
        .put(JSONObject().put("role", "user").put("content", content))
    val body = JSONObject()
        .put("model", model.ifBlank { "gpt-4.1-mini" })
        .put("messages", messages)
        .put("temperature", 0.2)
    val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .callTimeout(120, TimeUnit.SECONDS)
        .build()
    val request = Request.Builder()
        .url("https://api.openai.com/v1/chat/completions")
        .addHeader("Authorization", "Bearer ${apiKey.trim()}")
        .addHeader("Content-Type", "application/json")
        .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        .build()
    client.newCall(request).execute().use { response ->
        val responseText = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val detail = try { JSONObject(responseText).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            throw IllegalStateException(detail?.takeIf { it.isNotBlank() } ?: "Ошибка API (${response.code}). Проверь ключ и доступ к модели.")
        }
        val json = JSONObject(responseText)
        return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
            .ifBlank { "ИИ вернул пустой ответ. Попробуй переформулировать вопрос." }
    }
}
